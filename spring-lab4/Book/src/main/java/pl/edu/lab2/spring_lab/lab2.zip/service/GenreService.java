package pl.edu.lab2.spring_lab.service;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import pl.edu.lab2.spring_lab.entity.Genre;
import pl.edu.lab2.spring_lab.repository.*;

import java.util.List;
import java.util.UUID;

@Service
public class GenreService {
    private GenreRepository genreRepository;

    public GenreService(GenreRepository genreRepository) {
        this.genreRepository = genreRepository;
    }

    @Transactional
    public List<Genre> findAll() {
        return genreRepository.findAll();
    }

    public Genre findById(UUID id) {
        return genreRepository.findById(id).orElse(null);
    }

    public Genre add(Genre genre) {
        return genreRepository.save(genre);
    }

    public void delete(UUID id) {
        genreRepository.deleteById(id);
    }

}
