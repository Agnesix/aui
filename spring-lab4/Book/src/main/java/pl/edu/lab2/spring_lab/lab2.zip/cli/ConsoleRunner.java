package pl.edu.lab2.spring_lab.cli;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import pl.edu.lab2.spring_lab.entity.*;
import pl.edu.lab2.spring_lab.service.*;

import java.util.List;
import java.util.Scanner;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class ConsoleRunner implements CommandLineRunner {

    private final GenreService genreService;
    private final BookService bookService;

    private final Scanner scanner = new Scanner(System.in);

    @Override
    public void run(String... args) {
        System.out.println("📚 Welcome to the Book Library CLI!");

        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> listGenres();
                case "2" -> listBooks();
                case "3" -> addBook();
                case "4" -> deleteBook();
                case "5" -> running = false;
                default -> System.out.println("❌ Invalid option.");
            }
        }

        System.out.println("Application stopped.");
        System.exit(0);
    }

    private void printMenu() {
        System.out.println("\n=== MENU ===");
        System.out.println("1️⃣ List Genres");
        System.out.println("2️⃣ List Books");
        System.out.println("3️⃣ Add Book");
        System.out.println("4️⃣ Delete Book");
        System.out.println("5️⃣ Exit");
        System.out.print("Select option: ");
    }

    private void listGenres() {
        List<Genre> genres = genreService.findAll();
        if (genres.isEmpty()) {
            System.out.println("No genres found.");
        } else {
            genres.forEach(System.out::println);
        }
    }

    private void listBooks() {
        List<Book> books = bookService.findAll();
        if (books.isEmpty()) {
            System.out.println("No books found.");
        } else {
            books.forEach(System.out::println);
        }
    }

    private void addBook() {
        System.out.print("Title: ");
        String title = scanner.nextLine();

        System.out.print("Author: ");
        String author = scanner.nextLine();

        int isbn = 0;
        while (true) {
            System.out.print("ISBN (positive integer): ");
            try {
                isbn = Integer.parseInt(scanner.nextLine().trim());
                if (isbn > 0) break;
                System.out.println("⚠️  ISBN must be positive.");
            } catch (NumberFormatException e) {
                System.out.println("⚠️  Invalid number format.");
            }
        }

        int year = 0;
        while (true) {
            System.out.print("Year (positive integer < 2026): ");
            try {
                year = Integer.parseInt(scanner.nextLine().trim());
                if (year > 0 && year <2026) break;
                System.out.println("⚠️  Year must be positive number.");
            } catch (NumberFormatException e) {
                System.out.println("⚠️  Invalid number format.");
            }
        }

        System.out.println("Select Genre by index:");
        List<Genre> genres = genreService.findAll();
        for (int i = 0; i < genres.size(); i++) {
            System.out.println(i + " - " + genres.get(i).getName());
        }
        int genreIndex;
        while (true) {
            try {
                genreIndex = Integer.parseInt(scanner.nextLine());
                if (genreIndex > 0 && genreIndex < genreService.findAll().size()) break;
                System.out.println("⚠️  Invalid genre number.");
            } catch (NumberFormatException e) {
                System.out.println("⚠️  Invalid genre format.");
            }
        }

        Genre genre = genres.get(genreIndex);

        Book newBook = new Book(
                UUID.randomUUID(),
                isbn,
                title,
                author,
                year,
                genre
        );

        bookService.add(newBook);
        System.out.println("✅ Book added!");
    }

    private void deleteBook() {
        System.out.print("Enter Book UUID to delete: ");
        try {
            UUID id = UUID.fromString(scanner.nextLine());
            bookService.delete(id);
            System.out.println("✅ Book removed!");
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Invalid UUID.");
        }
    }
}
