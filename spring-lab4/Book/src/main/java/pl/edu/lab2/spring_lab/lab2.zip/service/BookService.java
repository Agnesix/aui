package pl.edu.lab2.spring_lab.service;

import org.springframework.stereotype.Service;
import pl.edu.lab2.spring_lab.entity.Book;
import pl.edu.lab2.spring_lab.entity.Genre;
import pl.edu.lab2.spring_lab.repository.*;

import java.util.List;
import java.util.UUID;

@Service
public class BookService {
    private BookRepository bookRepository;
    private GenreRepository genreRepository;

    public BookService(BookRepository bookRepository, GenreRepository genreRepository) {
        this.bookRepository = bookRepository;
        this.genreRepository = genreRepository;
    }

    public Book findById(UUID id) {
        return bookRepository.findById(id).orElse(null);
    }

    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    public List<Book> findByGenreId(UUID genreId) {
        Genre genre = genreRepository.findById(genreId).orElse(null);
        return bookRepository.findByGenreId(genreId);
    }

    public Book add(Book book) {
        return bookRepository.save(book);
    }

    public void delete(UUID id) {
        bookRepository.deleteById(id);
    }
}
