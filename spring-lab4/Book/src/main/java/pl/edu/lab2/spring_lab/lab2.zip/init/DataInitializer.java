package pl.edu.lab2.spring_lab.init;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import pl.edu.lab2.spring_lab.service.*;
import pl.edu.lab2.spring_lab.entity.*;

import java.util.*;


@Component
@RequiredArgsConstructor
public class DataInitializer {

    private final GenreService genreService;
    private final BookService bookService;

    @PostConstruct
    public void init() {
        // Create example genres
        Genre fantasy = new Genre(
                UUID.randomUUID(),
                "Fantasy",
                95,
                "Magic & adventure",
                Collections.emptyList()
        );

        Genre scifi = new Genre(
                UUID.randomUUID(),
                "Science Fiction",
                80,
                "Futures & tech",
                Collections.emptyList()
        );

        Genre nonfiction = new Genre(
                UUID.randomUUID(),
                "Non-Fiction",
                85,
                "Real world topics",
                Collections.emptyList()
        );

        genreService.add(fantasy);
        genreService.add(scifi);
        genreService.add(nonfiction);

        // Create example books
        Book book1 = new Book(
                UUID.randomUUID(),
                310,
                "The Hobbit",
                "J.R.R. Tolkien",
                1937,
                fantasy
        );

        Book book2 = new Book(
                UUID.randomUUID(),
                412,
                "Dune",
                "Frank Herbert",
                1965,
                scifi
        );

        Book book3 = new Book(
                UUID.randomUUID(),
                271,
                "Neuromancer",
                "William Gibson",
                1984,
                scifi
        );

        Book book4 = new Book(
                UUID.randomUUID(),
                662,
                "The Name of the Wind",
                "Patrick Rothfuss",
                2007,
                fantasy
        );

        Book book5 = new Book(
                UUID.randomUUID(),
                443,
                "Sapiens",
                "Juwal Noach Harari",
                2011,
                nonfiction
        );

        Book book6 = new Book(
                UUID.randomUUID(),
                334,
                "Educated",
                "Tara Westover",
                2018,
                nonfiction
        );

        bookService.add(book1);
        bookService.add(book2);
        bookService.add(book3);
        bookService.add(book4);
        bookService.add(book5);
        bookService.add(book6);

        System.out.println("✅ Example data inserted into H2 database!");
    }
}

