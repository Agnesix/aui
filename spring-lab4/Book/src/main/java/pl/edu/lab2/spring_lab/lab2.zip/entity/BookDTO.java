package pl.edu.lab2.spring_lab.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Objects;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "booksDTO")
@Entity
public class BookDTO {

    @Id
    @Column(name = "id")
    private UUID id;

    @Column(unique = true, name = "isbn")
    private int isbn;
    @Column(name = "title")
    private String title;
    @Column(name = "author")
    private String author;
    @Column(name = "publication_year")
    private int publicationYear;
    @Column(name = "genre_name")
    private String genreName;

    public int compareTo(Book o) {
        int cmp = this.title.compareToIgnoreCase(o.getTitle());
        if (cmp != 0) return cmp;
        return Integer.compare(this.publicationYear, o.getPublicationYear());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book)) return false;
        Book book = (Book) o;
        return isbn == book.getIsbn() &&
                publicationYear == book.getPublicationYear() &&
                Objects.equals(title, book.getTitle());
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, isbn, publicationYear);
    }

    @Override
    public String toString() {
        return String.format("BookDto{title='%s', author='%s', isbn=%d, year=%d, genre='%s'}",
                title, author, isbn, publicationYear, genreName);
    }
}
