package pl.edu.lab2.spring_lab.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "genres")
@Entity
public class Genre {

    @Id
    @Column(name = "id", columnDefinition = "CHAR(36)", nullable = false)
    private UUID id;
    @Column(name = "name")
    private String name;
    @Column(name = "popularity")
    private int popularity;
    @Column(name = "description")
    private String description;

    @OneToMany(mappedBy = "genre", fetch = FetchType.LAZY)
    private List<Book> books;

    public int compareTo(Genre o) {
        return this.name.compareToIgnoreCase(o.name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Genre)) return false;
        Genre genre = (Genre) o;
        return popularity == genre.popularity &&
                Objects.equals(name, genre.name) &&
                Objects.equals(description, genre.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, description, popularity);
    }

    @Override
    public String toString() {
        return String.format("Genre{id=" + id + " name='%s', popularity='%d', description='%s'}", name, popularity, description);
    }
}
